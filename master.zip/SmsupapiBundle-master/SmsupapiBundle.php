<?php

namespace smsup\SmsupapiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmsupapiBundle extends Bundle
{
}
